<?php

namespace Models;

class SystemSetup extends \Models\Base\SystemSetup
{
	protected $fillable = [
		'qb_include_recalls',
		'qb_incl_recalls_refer',
		'message_agent',
		'message_manager',
		'gifts',
		'book_app_days',
		'maturity_time',
		'maturity_time_hd',
		'maturity_time_hs',
		'app_boards',
		'ni_days',
		'ni_recycle_time',
		'scr_gas_out1',
		'scr_gas_out2',
		'scr_gas_in1',
		'scr_gas_in2',
		'scr_bd',
		'scr_flyer',
		'scr_app_mail1',
		'scr_app_mail2',
		'scr_app_mail3',
		'scr_app_mail4',
		'scr_app_mail5',
		'scr_app_mail6'
	];
}
