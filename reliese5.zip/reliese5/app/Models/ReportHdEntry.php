<?php

namespace Models;

class ReportHdEntry extends \Models\Base\ReportHdEntry
{
	protected $fillable = [
		'date_entry',
		'id_user_add',
		'id_hd_marketeer',
		'id_loc_marketeer',
		'hd_source',
		'hd_type',
		'id_lead'
	];
}
