<?php

namespace Models;

class QuadrantsFlyerZips1 extends \Models\Base\QuadrantsFlyerZips1
{
	protected $fillable = [
		'id_quadrant',
		'zip'
	];
}
