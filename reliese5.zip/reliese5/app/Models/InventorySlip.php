<?php

namespace Models;

class InventorySlip extends \Models\Base\InventorySlip
{
	protected $fillable = [
		'order_number',
		'order_date',
		'purchase_order',
		'document_number',
		'inventory_picker',
		'comments',
		'id_distributor_ship_to',
		'id_distributor_bill_to',
		'content',
		'deleted',
		'finalized',
		'date_finalized'
	];
}
