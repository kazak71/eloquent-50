<?php

namespace Models;

class TransferredSet extends \Models\Base\TransferredSet
{
	protected $fillable = [
		'id_set',
		'date_transfer',
		'id_user'
	];
}
