<?php

namespace Models;

class OfficeReceptionist extends \Models\Base\OfficeReceptionist
{
	protected $fillable = [
		'fname',
		'lname',
		'date_hired',
		'people_called',
		'people_interviewed',
		'id_system_users',
		'deleted'
	];
}
