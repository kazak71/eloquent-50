<?php

namespace Models;

class AppInstall extends \Models\Base\AppInstall
{
	protected $fillable = [
		'id_app',
		'id_salesrep',
		'id_installer',
		'id_board',
		'app_date',
		'app_time',
		'app_order',
		'id_booker',
		'book_date',
		'not_active',
		'not_active_date',
		'not_active_reason',
		'return_reason',
		'is_confirmed',
		'id_confirmer',
		'confirm_date',
		'installer_in',
		'installer_out',
		'notes_to_rep',
		'sms_time',
		'ref_num',
		'status',
		'sld_status',
		'fin_status',
		'sold_type',
		'fin_by',
		'is_sld',
		'is_edit',
		'sold_system',
		'sold_system_qty',
		'app_notes',
		'delivered',
		'reset_date'
	];
}
