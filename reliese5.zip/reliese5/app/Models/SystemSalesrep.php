<?php

namespace Models;

class SystemSalesrep extends \Models\Base\SystemSalesrep
{
	protected $fillable = [
		'fname',
		'lname',
		'id_provider',
		'tel_cell',
		'tel_home',
		'fax',
		'city',
		'post_code',
		'addr1',
		'addr2',
		'trainer',
		'last_digits_ssn',
		'deleted',
		'email',
		'associate_number',
		'inactive',
		'date_created'
	];
}
