<?php

namespace Models;

class ReportLadsiBdEntry extends \Models\Base\ReportLadsiBdEntry
{
	protected $fillable = [
		'report_for',
		'prize_give_away',
		'premiums',
		'printing',
		'lead cards',
		'mailers',
		'bd_sheets',
		'signs',
		'hand_outs',
		'labor',
		'commissions',
		'bonuses',
		'postage_out',
		'postage_in',
		'fees_for_show',
		'supplies',
		'bottles',
		'drop_boxes',
		'misc'
	];
}
