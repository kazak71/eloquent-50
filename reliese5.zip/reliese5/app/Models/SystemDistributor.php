<?php

namespace Models;

class SystemDistributor extends \Models\Base\SystemDistributor
{
	protected $fillable = [
		'fname',
		'lname',
		'tel_cell',
		'tel_home',
		'fax',
		'city',
		'post_code',
		'addr1',
		'addr2',
		'company',
		'email',
		'deleted',
		'shipping_contact',
		'db'
	];
}
