<?php

namespace Models;

class Appointments1 extends \Models\Base\Appointments1
{
	protected $fillable = [
		'id_lead',
		'id_salesrep',
		'id_board',
		'app_date',
		'app_time',
		'app_order',
		'id_booker',
		'book_date',
		'not_active',
		'not_active_date',
		'not_active_reason',
		'return_reason',
		'is_confirmed',
		'id_confirmer',
		'confirm_date',
		'salesrep_in',
		'salesrep_out',
		'notes_to_rep',
		'sms_time',
		'ref_num',
		'status',
		'sld_status',
		'fin_status',
		'sold_type',
		'fin_by',
		'is_sld',
		'is_edit',
		'sold_system',
		'sold_system_qty',
		'app_notes',
		'delivered',
		'reset_date'
	];
}
