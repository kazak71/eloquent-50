<?php

namespace Models;

class MaterialSent extends \Models\Base\MaterialSent
{
	protected $fillable = [
		'date_sent',
		'lead_type',
		'lead_subtype',
		'quantity'
	];
}
