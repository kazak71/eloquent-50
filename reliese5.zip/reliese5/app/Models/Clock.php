<?php

namespace Models;

class Clock extends \Models\Base\Clock
{
	protected $fillable = [
		'clock_time',
		'user_id',
		'direction',
		'photo'
	];
}
