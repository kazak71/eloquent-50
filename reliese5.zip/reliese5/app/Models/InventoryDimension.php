<?php

namespace Models;

class InventoryDimension extends \Models\Base\InventoryDimension
{
	protected $fillable = [
		'dimension'
	];
}
