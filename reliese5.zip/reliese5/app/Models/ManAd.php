<?php

namespace Models;

class ManAd extends \Models\Base\ManAd
{
	protected $fillable = [
		'id_manager',
		'ad_place',
		'ad_price',
		'ad_start_date',
		'ad_end_date',
		'ad_text',
		'ad_deleted',
		'ad_title',
		'ad_calls',
		'ad_hired'
	];
}
