<?php

namespace Models;

class SystemHdSource extends \Models\Base\SystemHdSource
{
	protected $fillable = [
		'name',
		'goal',
		'goal_enabled'
	];
}
