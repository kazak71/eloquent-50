<?php

namespace Models;

class Quadrant extends \Models\Base\Quadrant
{
	protected $fillable = [
		'name',
		'hold',
		'survey_date',
		'setting_date',
		'survey_priority',
		'setter_priority'
	];
}
