<?php

namespace Models;

class SurveyCost extends \Models\Base\SurveyCost
{
	protected $fillable = [
		'cost',
		'last_updated'
	];
}
