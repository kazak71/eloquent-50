<?php

namespace Models;

class QuadrantsFlyer extends \Models\Base\QuadrantsFlyer
{
	protected $fillable = [
		'name',
		'setting_date',
		'setter_priority',
		'hold'
	];
}
