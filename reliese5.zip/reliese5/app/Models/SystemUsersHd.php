<?php

namespace Models;

class SystemUsersHd extends \Models\Base\SystemUsersHd
{
	protected $fillable = [
		'user_id',
		'fname',
		'lname',
		'type',
		'date_add',
		'deleted',
		'date_delete'
	];
}
