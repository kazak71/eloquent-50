<?php

namespace Models;

class CallsOnAd extends \Models\Base\CallsOnAd
{
	protected $fillable = [
		'id_ad',
		'fname',
		'lname',
		'tel_cell',
		'tel_home',
		'e_mail',
		'address1',
		'address2',
		'city',
		'state',
		'zip',
		'date_call',
		'trainer_arranged',
		'approved',
		'interview_time',
		'interview_date',
		'deleted',
		'hired',
		'status'
	];
}
