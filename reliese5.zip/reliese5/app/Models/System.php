<?php

namespace Models;

class System extends \Models\Base\System
{
	protected $hidden = [
		'api_password'
	];

	protected $fillable = [
		'fname',
		'lname',
		'tel_cell',
		'tel_home',
		'fax',
		'city',
		'post_code',
		'addr1',
		'addr2',
		'shipping_contact',
		'company',
		'email',
		'url',
		'type',
		'api_username',
		'api_password'
	];
}
