<?php

namespace Models;

class ReportProductivity extends \Models\Base\ReportProductivity
{
	protected $fillable = [
		'hours_worked',
		'total_calls',
		'total_sets',
		'total_NI',
		'total_leads_run'
	];
}
