<?php

namespace Models;

class InventoryPo extends \Models\Base\InventoryPo
{
	protected $fillable = [
		'order_number',
		'order_date',
		'purchase_order',
		'document_number',
		'comments',
		'id_company_ship_to',
		'id_company_sold_to',
		'id_target_system',
		'content',
		'deleted',
		'finalized',
		'sent'
	];
}
