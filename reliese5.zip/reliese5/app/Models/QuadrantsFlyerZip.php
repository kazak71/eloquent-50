<?php

namespace Models;

class QuadrantsFlyerZip extends \Models\Base\QuadrantsFlyerZip
{
	protected $fillable = [
		'id_quadrant',
		'zip'
	];
}
