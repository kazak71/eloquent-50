<?php

namespace Models;

class SystemScriptsHd extends \Models\Base\SystemScriptsHd
{
	protected $fillable = [
		'script',
		'id_type',
		'lead_type'
	];
}
