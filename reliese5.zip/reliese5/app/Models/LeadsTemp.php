<?php

namespace Models;

class LeadsTemp extends \Models\Base\LeadsTemp
{
	protected $fillable = [
		'name',
		'address',
		'city',
		'state',
		'zip',
		'lead_type',
		'lead_subtype'
	];
}
