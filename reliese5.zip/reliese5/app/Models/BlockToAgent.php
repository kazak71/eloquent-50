<?php

namespace Models;

class BlockToAgent extends \Models\Base\BlockToAgent
{
	protected $fillable = [
		'id_set',
		'id_quadr',
		'block',
		'na_level',
		'id_user',
		'date_assign',
		'note'
	];
}
