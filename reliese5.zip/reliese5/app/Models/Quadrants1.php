<?php

namespace Models;

class Quadrants1 extends \Models\Base\Quadrants1
{
	protected $fillable = [
		'name',
		'hold',
		'survey_date',
		'setting_date',
		'survey_priority',
		'setter_priority'
	];
}
