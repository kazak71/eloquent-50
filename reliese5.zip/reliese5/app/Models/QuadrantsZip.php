<?php

namespace Models;

class QuadrantsZip extends \Models\Base\QuadrantsZip
{
	protected $fillable = [
		'id_quadrant',
		'zip'
	];
}
