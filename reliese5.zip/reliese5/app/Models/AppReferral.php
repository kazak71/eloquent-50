<?php

namespace Models;

class AppReferral extends \Models\Base\AppReferral
{
	protected $fillable = [
		'id_lead',
		'id_salesrep',
		'id_recommender',
		'id_app'
	];
}
