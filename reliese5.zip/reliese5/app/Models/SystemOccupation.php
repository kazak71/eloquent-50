<?php

namespace Models;

class SystemOccupation extends \Models\Base\SystemOccupation
{
	protected $fillable = [
		'occupation',
		'work_status',
		'deleted'
	];
}
