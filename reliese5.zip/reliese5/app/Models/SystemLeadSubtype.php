<?php

namespace Models;

class SystemLeadSubtype extends \Models\Base\SystemLeadSubtype
{
	protected $fillable = [
		'subtype',
		'lead_type',
		'deleted'
	];
}
