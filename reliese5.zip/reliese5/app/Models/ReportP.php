<?php

namespace Models;

class ReportP extends \Models\Base\ReportP
{
	protected $fillable = [
		'id_user',
		'id_lead',
		'date_survey',
		'id_booker',
		'date_ps',
		'script'
	];
}
