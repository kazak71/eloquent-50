<?php

namespace Models;

class Appointment extends \Models\Base\Appointment
{
	protected $fillable = [
		'id_lead',
		'id_salesrep',
		'id_installer',
		'id_board',
		'app_date',
		'app_time',
		'app_order',
		'id_booker',
		'book_date',
		'not_active',
		'not_active_date',
		'not_active_reason',
		'return_reason',
		'is_confirmed',
		'id_confirmer',
		'confirm_date',
		'salesrep_in',
		'salesrep_out',
		'notes_to_rep',
		'sms_time',
		'ref_num',
		'status',
		'sld_status',
		'fin_status',
		'sold_type',
		'fin_by',
		'is_sld',
		'is_edit',
		'sold_system',
		'sold_system_qty',
		'app_notes',
		'delivered',
		'reset_date',
		'transfer_to_service_time',
		'transfer_to_service_user',
		'id_user_app_mail',
		'app_mail_date',
		'id_user_gc_hd_mail',
		'gc_hd_mail_date',
		'gc_hd_mail_sent_to',
		'gc_hd_id',
		'id_user_gc_jcp_mail',
		'gc_jcp_mail_date',
		'gc_jcp_mail_sent_to',
		'gc_jcp_id'
	];
}
