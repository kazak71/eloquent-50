<?php

namespace Models;

class SystemUser extends \Models\Base\SystemUser
{
	protected $fillable = [
		'username',
		'pass',
		'type',
		'subtype',
		'fname',
		'lname',
		'date_add',
		'date_delete',
		'deleted',
		'hourly_rate',
		'ssn',
		'id_salesrep',
		'inactive',
		'home_phone',
		'cell_phone',
		'cell_provider',
		'city',
		'zip_postal',
		'address1',
		'associate_number',
		'email',
		'user_id',
		'hd_source',
		'first_login_at',
		'showed_message_at',
		'made_hd_surveys'
	];
}
