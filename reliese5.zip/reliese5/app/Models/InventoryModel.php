<?php

namespace Models;

class InventoryModel extends \Models\Base\InventoryModel
{
	protected $fillable = [
		'partno',
		'description',
		'material',
		'finish_color',
		'type',
		'deleted',
		'belong_to',
		'api_type',
		'api_username',
		'api_model_id',
		'last_modified',
		'tbd_view',
		'gift',
		'price'
	];
}
