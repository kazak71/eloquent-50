<?php

namespace Models;

class LeadsGiftCard extends \Models\Base\LeadsGiftCard
{
	protected $fillable = [
		'name',
		'phone',
		'best_contact_date',
		'best_contact_time',
		'address',
		'city',
		'state',
		'zip',
		'email',
		'email_2',
		'agree_terms',
		'home_owner',
		'eat_out',
		'eatprefer',
		'restaurant_frequented',
		'give_opinion',
		'bottle_water',
		'bottle_water_type',
		'home_devices',
		'home_type',
		'household_head',
		'amazon_shopped',
		'amazon_average_purchase',
		'websites_shop',
		'age',
		'occupants',
		'work_in',
		'work_in_m',
		'date_survey',
		'card_type',
		'recall_date',
		'id_booker_recall',
		'book_status',
		'id_booker',
		'booker_lastcall',
		'nh_level_book',
		'id_lead',
		'date_transfer',
		'occupation'
	];
}
