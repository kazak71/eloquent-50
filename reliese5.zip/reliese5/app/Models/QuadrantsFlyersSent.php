<?php

namespace Models;

class QuadrantsFlyersSent extends \Models\Base\QuadrantsFlyersSent
{
	protected $fillable = [
		'id_quadrant',
		'date_sent',
		'flyers_sent'
	];
}
