<?php

namespace Models;

class QuadrantBlocks1 extends \Models\Base\QuadrantBlocks1
{
	protected $fillable = [
		'id_quadrant',
		'quadrant',
		'empl',
		'is_nh',
		'id_lead',
		'id_booker',
		'time_assigned',
		'is_car_regy',
		'block_type'
	];
}
