<?php

namespace Models;

class InventorySlipReceived extends \Models\Base\InventorySlipReceived
{
	protected $fillable = [
		'order_number',
		'order_date',
		'document_number',
		'source_system_username',
		'source_system_db',
		'date_finalized'
	];
}
