<?php

namespace Models;

class QuadrantBlRefer extends \Models\Base\QuadrantBlRefer
{
	protected $fillable = [
		'id_salesrep',
		'quadrant',
		'is_nh',
		'id_lead',
		'id_booker',
		'time_assigned'
	];
}
