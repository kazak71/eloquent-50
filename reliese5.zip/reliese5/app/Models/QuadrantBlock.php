<?php

namespace Models;

class QuadrantBlock extends \Models\Base\QuadrantBlock
{
	protected $fillable = [
		'id_quadrant',
		'quadrant',
		'empl',
		'is_nh',
		'is_ni',
		'id_lead',
		'id_booker',
		'time_assigned',
		'assigned_to',
		'is_car_regy',
		'block_type',
		'block_subtype'
	];
}
