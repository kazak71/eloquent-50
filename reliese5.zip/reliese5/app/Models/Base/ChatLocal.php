<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ChatLocal
 * 
 * @property int $id
 * @property int $id_sender
 * @property int $id_receiver
 * @property string $message
 * @property \Carbon\Carbon $date_sent
 * @property int $readed
 *
 * @package Models\Base
 */
class ChatLocal extends Eloquent
{
	protected $table = 'chat_local';
	public $timestamps = false;

	protected $casts = [
		'id_sender' => 'int',
		'id_receiver' => 'int',
		'readed' => 'int'
	];

	protected $dates = [
		'date_sent'
	];
}
