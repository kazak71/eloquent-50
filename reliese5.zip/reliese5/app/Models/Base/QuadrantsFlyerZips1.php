<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class QuadrantsFlyerZips1
 * 
 * @property int $id
 * @property int $id_quadrant
 * @property string $zip
 *
 * @package Models\Base
 */
class QuadrantsFlyerZips1 extends Eloquent
{
	protected $table = 'quadrants_flyer_zips_1';
	public $timestamps = false;

	protected $casts = [
		'id_quadrant' => 'int'
	];
}
