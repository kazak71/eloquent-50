<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class QuadrantBlRefer
 * 
 * @property int $id
 * @property int $id_salesrep
 * @property string $quadrant
 * @property bool $is_nh
 * @property int $id_lead
 * @property int $id_booker
 * @property \Carbon\Carbon $time_assigned
 *
 * @package Models\Base
 */
class QuadrantBlRefer extends Eloquent
{
	protected $table = 'quadrant_bl_refer';
	public $timestamps = false;

	protected $casts = [
		'id_salesrep' => 'int',
		'is_nh' => 'bool',
		'id_lead' => 'int',
		'id_booker' => 'int'
	];

	protected $dates = [
		'time_assigned'
	];
}
