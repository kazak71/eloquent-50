<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemOccupation
 * 
 * @property int $id
 * @property string $occupation
 * @property string $work_status
 * @property int $deleted
 *
 * @package Models\Base
 */
class SystemOccupation extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'deleted' => 'int'
	];
}
