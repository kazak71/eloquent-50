<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class BlockToAgent
 * 
 * @property int $id
 * @property int $id_set
 * @property int $id_quadr
 * @property int $block
 * @property int $na_level
 * @property int $id_user
 * @property \Carbon\Carbon $date_assign
 * @property string $note
 *
 * @package Models\Base
 */
class BlockToAgent extends Eloquent
{
	protected $table = 'block_to_agent';
	public $timestamps = false;

	protected $casts = [
		'id_set' => 'int',
		'id_quadr' => 'int',
		'block' => 'int',
		'na_level' => 'int',
		'id_user' => 'int'
	];

	protected $dates = [
		'date_assign'
	];
}
