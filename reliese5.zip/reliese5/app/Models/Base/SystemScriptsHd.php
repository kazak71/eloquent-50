<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemScriptsHd
 * 
 * @property int $id
 * @property string $script
 * @property int $id_type
 * @property string $lead_type
 *
 * @package Models\Base
 */
class SystemScriptsHd extends Eloquent
{
	protected $table = 'system_scripts_hd';
	public $timestamps = false;

	protected $casts = [
		'id_type' => 'int'
	];
}
