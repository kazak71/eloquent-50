<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class QuadrantsFlyersSent
 * 
 * @property int $id
 * @property int $id_quadrant
 * @property \Carbon\Carbon $date_sent
 * @property int $flyers_sent
 *
 * @package Models\Base
 */
class QuadrantsFlyersSent extends Eloquent
{
	protected $table = 'quadrants_flyers_sent';
	public $timestamps = false;

	protected $casts = [
		'id_quadrant' => 'int',
		'flyers_sent' => 'int'
	];

	protected $dates = [
		'date_sent'
	];
}
