<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class AppReferral
 * 
 * @property int $id
 * @property int $id_lead
 * @property int $id_salesrep
 * @property int $id_recommender
 * @property int $id_app
 *
 * @package Models\Base
 */
class AppReferral extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_lead' => 'int',
		'id_salesrep' => 'int',
		'id_recommender' => 'int',
		'id_app' => 'int'
	];
}
