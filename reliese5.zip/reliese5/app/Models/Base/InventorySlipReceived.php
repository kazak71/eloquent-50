<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class InventorySlipReceived
 * 
 * @property int $id
 * @property int $order_number
 * @property \Carbon\Carbon $order_date
 * @property string $document_number
 * @property string $source_system_username
 * @property string $source_system_db
 * @property \Carbon\Carbon $date_finalized
 *
 * @package Models\Base
 */
class InventorySlipReceived extends Eloquent
{
	protected $table = 'inventory_slip_received';
	public $timestamps = false;

	protected $casts = [
		'order_number' => 'int'
	];

	protected $dates = [
		'order_date',
		'date_finalized'
	];
}
