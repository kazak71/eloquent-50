<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class InventoryModel
 * 
 * @property int $id
 * @property string $partno
 * @property string $description
 * @property string $material
 * @property string $finish_color
 * @property int $type
 * @property int $deleted
 * @property string $belong_to
 * @property string $api_type
 * @property string $api_username
 * @property int $api_model_id
 * @property int $last_modified
 * @property int $tbd_view
 * @property int $gift
 * @property string $price
 *
 * @package Models\Base
 */
class InventoryModel extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'type' => 'int',
		'deleted' => 'int',
		'api_model_id' => 'int',
		'last_modified' => 'int',
		'tbd_view' => 'int',
		'gift' => 'int'
	];
}
