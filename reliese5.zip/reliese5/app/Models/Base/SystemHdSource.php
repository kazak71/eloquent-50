<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemHdSource
 * 
 * @property int $id
 * @property string $name
 * @property int $goal
 * @property bool $goal_enabled
 *
 * @package Models\Base
 */
class SystemHdSource extends Eloquent
{
	protected $table = 'system_hd_source';
	public $timestamps = false;

	protected $casts = [
		'goal' => 'int',
		'goal_enabled' => 'bool'
	];
}
