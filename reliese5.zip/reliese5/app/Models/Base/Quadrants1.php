<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Quadrants1
 * 
 * @property int $id
 * @property string $name
 * @property bool $hold
 * @property \Carbon\Carbon $survey_date
 * @property \Carbon\Carbon $setting_date
 * @property int $survey_priority
 * @property int $setter_priority
 *
 * @package Models\Base
 */
class Quadrants1 extends Eloquent
{
	protected $table = 'quadrants_1';
	public $timestamps = false;

	protected $casts = [
		'hold' => 'bool',
		'survey_priority' => 'int',
		'setter_priority' => 'int'
	];

	protected $dates = [
		'survey_date',
		'setting_date'
	];
}
