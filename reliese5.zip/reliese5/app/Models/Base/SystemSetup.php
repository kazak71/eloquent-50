<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemSetup
 * 
 * @property int $id
 * @property bool $qb_include_recalls
 * @property bool $qb_incl_recalls_refer
 * @property string $message_agent
 * @property string $message_manager
 * @property string $gifts
 * @property int $book_app_days
 * @property int $maturity_time
 * @property int $maturity_time_hd
 * @property int $maturity_time_hs
 * @property int $app_boards
 * @property int $ni_days
 * @property int $ni_recycle_time
 * @property string $scr_gas_out1
 * @property string $scr_gas_out2
 * @property string $scr_gas_in1
 * @property string $scr_gas_in2
 * @property string $scr_bd
 * @property string $scr_flyer
 * @property string $scr_app_mail1
 * @property string $scr_app_mail2
 * @property string $scr_app_mail3
 * @property string $scr_app_mail4
 * @property string $scr_app_mail5
 * @property string $scr_app_mail6
 *
 * @package Models\Base
 */
class SystemSetup extends Eloquent
{
	protected $table = 'system_setup';
	public $timestamps = false;

	protected $casts = [
		'qb_include_recalls' => 'bool',
		'qb_incl_recalls_refer' => 'bool',
		'book_app_days' => 'int',
		'maturity_time' => 'int',
		'maturity_time_hd' => 'int',
		'maturity_time_hs' => 'int',
		'app_boards' => 'int',
		'ni_days' => 'int',
		'ni_recycle_time' => 'int'
	];
}
