<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ReportLadsiBdEntry
 * 
 * @property int $id
 * @property \Carbon\Carbon $report_for
 * @property float $prize_give_away
 * @property float $premiums
 * @property float $printing
 * @property float $lead cards
 * @property float $mailers
 * @property float $bd_sheets
 * @property float $signs
 * @property float $hand_outs
 * @property float $labor
 * @property float $commissions
 * @property float $bonuses
 * @property float $postage_out
 * @property float $postage_in
 * @property float $fees_for_show
 * @property float $supplies
 * @property float $bottles
 * @property float $drop_boxes
 * @property float $misc
 *
 * @package Models\Base
 */
class ReportLadsiBdEntry extends Eloquent
{
	protected $table = 'report_ladsi_bd_entry';
	public $timestamps = false;

	protected $casts = [
		'prize_give_away' => 'float',
		'premiums' => 'float',
		'printing' => 'float',
		'lead cards' => 'float',
		'mailers' => 'float',
		'bd_sheets' => 'float',
		'signs' => 'float',
		'hand_outs' => 'float',
		'labor' => 'float',
		'commissions' => 'float',
		'bonuses' => 'float',
		'postage_out' => 'float',
		'postage_in' => 'float',
		'fees_for_show' => 'float',
		'supplies' => 'float',
		'bottles' => 'float',
		'drop_boxes' => 'float',
		'misc' => 'float'
	];

	protected $dates = [
		'report_for'
	];
}
