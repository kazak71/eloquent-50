<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class OfficeReceptionist
 * 
 * @property int $id_receptionist
 * @property string $fname
 * @property string $lname
 * @property \Carbon\Carbon $date_hired
 * @property int $people_called
 * @property int $people_interviewed
 * @property int $id_system_users
 * @property bool $deleted
 *
 * @package Models\Base
 */
class OfficeReceptionist extends Eloquent
{
	protected $primaryKey = 'id_receptionist';
	public $timestamps = false;

	protected $casts = [
		'people_called' => 'int',
		'people_interviewed' => 'int',
		'id_system_users' => 'int',
		'deleted' => 'bool'
	];

	protected $dates = [
		'date_hired'
	];
}
