<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ReportHdEntry
 * 
 * @property int $id
 * @property \Carbon\Carbon $date_entry
 * @property int $id_user_add
 * @property int $id_hd_marketeer
 * @property int $id_loc_marketeer
 * @property string $hd_source
 * @property string $hd_type
 * @property int $id_lead
 *
 * @package Models\Base
 */
class ReportHdEntry extends Eloquent
{
	protected $table = 'report_hd_entry';
	public $timestamps = false;

	protected $casts = [
		'id_user_add' => 'int',
		'id_hd_marketeer' => 'int',
		'id_loc_marketeer' => 'int',
		'id_lead' => 'int'
	];

	protected $dates = [
		'date_entry'
	];
}
