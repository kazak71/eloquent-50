<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class QuadrantBlock
 * 
 * @property int $id
 * @property int $id_quadrant
 * @property string $quadrant
 * @property string $empl
 * @property int $is_nh
 * @property int $is_ni
 * @property int $id_lead
 * @property int $id_booker
 * @property \Carbon\Carbon $time_assigned
 * @property string $assigned_to
 * @property int $is_car_regy
 * @property string $block_type
 * @property string $block_subtype
 *
 * @package Models\Base
 */
class QuadrantBlock extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_quadrant' => 'int',
		'is_nh' => 'int',
		'is_ni' => 'int',
		'id_lead' => 'int',
		'id_booker' => 'int',
		'is_car_regy' => 'int'
	];

	protected $dates = [
		'time_assigned'
	];
}
