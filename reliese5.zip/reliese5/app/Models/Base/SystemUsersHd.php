<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:30 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemUsersHd
 * 
 * @property int $id
 * @property string $user_id
 * @property string $fname
 * @property string $lname
 * @property string $type
 * @property \Carbon\Carbon $date_add
 * @property int $deleted
 * @property \Carbon\Carbon $date_delete
 *
 * @package Models\Base
 */
class SystemUsersHd extends Eloquent
{
	protected $table = 'system_users_hd';
	public $timestamps = false;

	protected $casts = [
		'deleted' => 'int'
	];

	protected $dates = [
		'date_add',
		'date_delete'
	];
}
