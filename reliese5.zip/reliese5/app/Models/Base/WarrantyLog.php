<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:30 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class WarrantyLog
 * 
 * @property int $warranty_id
 * @property string $first_name
 * @property string $last_name
 * @property string $street_address
 * @property string $address_line_2
 * @property string $city
 * @property string $state
 * @property string $zip
 * @property string $home_phone
 * @property string $email
 * @property string $model
 * @property string $serial_number
 * @property \Carbon\Carbon $date_purchased
 * @property string $associate_name
 * @property string $associate_number
 * @property string $phone_pro_name
 * @property int $id_app
 * @property int $id_lead
 *
 * @package Models\Base
 */
class WarrantyLog extends Eloquent
{
	protected $table = 'warranty_log';
	protected $primaryKey = 'warranty_id';
	public $timestamps = false;

	protected $casts = [
		'id_app' => 'int',
		'id_lead' => 'int'
	];

	protected $dates = [
		'date_purchased'
	];
}
