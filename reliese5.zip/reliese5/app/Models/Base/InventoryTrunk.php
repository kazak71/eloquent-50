<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class InventoryTrunk
 * 
 * @property int $id
 * @property int $id_inventory_main
 * @property int $id_salesrep
 * @property int $quantity
 * @property \Carbon\Carbon $date_modified
 *
 * @package Models\Base
 */
class InventoryTrunk extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_inventory_main' => 'int',
		'id_salesrep' => 'int',
		'quantity' => 'int'
	];

	protected $dates = [
		'date_modified'
	];
}
