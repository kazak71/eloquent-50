<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ClockTime
 * 
 * @property int $clock_id
 * @property \Carbon\Carbon $clock_time
 * @property \Carbon\Carbon $clock_date
 * @property \Carbon\Carbon $cl_time
 * @property string $user_names
 * @property string $direction
 * @property int $user_id
 * @property \Carbon\Carbon $time_total
 * @property string $photo
 *
 * @package Models\Base
 */
class ClockTime extends Eloquent
{
	protected $primaryKey = 'clock_id';
	public $timestamps = false;

	protected $casts = [
		'user_id' => 'int'
	];

	protected $dates = [
		'clock_time',
		'clock_date',
		'cl_time',
		'time_total'
	];
}
