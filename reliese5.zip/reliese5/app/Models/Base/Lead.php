<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Lead
 * 
 * @property int $id
 * @property int $lead_num
 * @property string $name
 * @property string $name_spouse
 * @property string $address
 * @property int $number
 * @property string $suite
 * @property string $city
 * @property string $state
 * @property string $zip
 * @property string $postal_code_prefix
 * @property string $phone
 * @property string $phone_orig
 * @property int $id_set
 * @property int $block
 * @property int $id_quadr
 * @property int $id_quadr_flyer
 * @property string $status
 * @property int $na_level
 * @property string $survey_mr_mrs
 * @property string $booker_mr_mrs
 * @property string $family_status
 * @property string $age
 * @property string $age_spouse
 * @property string $allergy_problems
 * @property string $allergy_type
 * @property string $allergy_at_work
 * @property string $cleaning_system
 * @property string $vacuum_age_yrs
 * @property string $own_home
 * @property string $air_pollution
 * @property string $smokers
 * @property string $pets
 * @property string $laundry_detergent
 * @property string $credit_card
 * @property string $employment
 * @property string $employment_spouse
 * @property string $occupation
 * @property string $occupation_spouse
 * @property string $work_period
 * @property string $work_period_spouse
 * @property string $car_year
 * @property string $home_constr
 * @property string $recycle_home
 * @property string $recycle_work
 * @property string $recycle_appliances
 * @property string $use_solar_energy
 * @property string $pet_name
 * @property string $high_school
 * @property string $hobby
 * @property string $mind_contact_again
 * @property string $contact_again
 * @property string $jcp_depart_visit
 * @property string $jcp_offers_aware
 * @property string $jcp_purchase_times
 * @property \Carbon\Carbon $date_survey
 * @property int $id_user_survey
 * @property string $book_status
 * @property int $id_booker
 * @property \Carbon\Carbon $booker_lastcall
 * @property \Carbon\Carbon $recall_date
 * @property int $id_booker_recall
 * @property int $ni_level_book
 * @property int $nh_level_book
 * @property string $notes
 * @property string $notes_sld
 * @property string $lead_type
 * @property string $lead_subtype
 * @property string $source
 * @property string $hd_source
 * @property string $hd_marketeer
 * @property int $hd_local_marketeer
 * @property int $contact_counter
 * @property \Carbon\Carbon $upload_date
 * @property int $id_add_user
 * @property string $use_energy_star
 * @property string $use_heat
 * @property string $own_years
 * @property string $air_type
 * @property string $num_of_people
 * @property string $furn_efficiency
 * @property string $vehicles_use
 * @property string $vehicles_yrs
 * @property string $comm_to_work
 * @property string $work_in
 * @property string $retired_age
 * @property string $ret_work_field
 * @property string $comm_to_work_m
 * @property string $work_in_m
 * @property string $ret_work_field_m
 * @property string $gas_interested
 * @property int $transferred_to_crm
 * @property \Carbon\Carbon $reset_date
 * @property string $email
 * @property string $email_2
 * @property string $phone_2
 * @property string $cell
 * @property string $cell_2
 * @property string $Buyer1_fname
 * @property string $Buyer1_lname
 * @property string $Buyer2_fname
 * @property string $Buyer2_lname
 * @property string $buyer1_work
 * @property string $buyer2_work
 * @property string $buyer1_work_phone
 * @property string $buyer2_work_phone
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property string $water
 * @property string $water_note
 * @property string $water_issues
 * @property string $water_issues_note
 * @property string $water_softener
 * @property string $water_softener_note
 * @property string $softener_age
 * @property string $odors
 * @property string $filter_water
 * @property string $filter_water_note
 * @property string $people
 * @property \Carbon\Carbon $date_taken
 * @property int $exper_chlorine_smell
 * @property int $exper_salty_taste
 * @property int $exper_rust_stains
 * @property int $exper_rotten_egg_smell
 * @property int $exper_blue_green_stains
 * @property int $exper_scale_deposits
 * @property int $exper_cloudiness
 * @property int $exper_other
 * @property string $exper_other_note
 * @property string $water_test_want
 * @property string $water_tested
 * @property string $water_tested_note
 * @property string $bottled_water
 * @property string $bottled_water_note
 * @property string $people_adults
 * @property string $people_children
 * @property string $people_pets
 * @property string $water_changes
 * @property string $residents_name
 * @property string $signature
 * @property \Carbon\Carbon $signature_date
 * @property string $signature_tablet
 * @property string $water_rate
 * @property string $water_rate_note
 * @property int $is_dnc
 * @property \Carbon\Carbon $dnc_date
 * @property int $id_lead_web
 * @property \Carbon\Carbon $date_transfer_weblead
 * @property string $comments
 * @property string $ph
 * @property string $hardness
 * @property string $tds
 * @property string $house_value
 * @property string $home_year
 *
 * @package Models\Base
 */
class Lead extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'lead_num' => 'int',
		'number' => 'int',
		'id_set' => 'int',
		'block' => 'int',
		'id_quadr' => 'int',
		'id_quadr_flyer' => 'int',
		'na_level' => 'int',
		'id_user_survey' => 'int',
		'id_booker' => 'int',
		'id_booker_recall' => 'int',
		'ni_level_book' => 'int',
		'nh_level_book' => 'int',
		'hd_local_marketeer' => 'int',
		'contact_counter' => 'int',
		'id_add_user' => 'int',
		'transferred_to_crm' => 'int',
		'exper_chlorine_smell' => 'int',
		'exper_salty_taste' => 'int',
		'exper_rust_stains' => 'int',
		'exper_rotten_egg_smell' => 'int',
		'exper_blue_green_stains' => 'int',
		'exper_scale_deposits' => 'int',
		'exper_cloudiness' => 'int',
		'exper_other' => 'int',
		'is_dnc' => 'int',
		'id_lead_web' => 'int'
	];

	protected $dates = [
		'date_survey',
		'booker_lastcall',
		'recall_date',
		'upload_date',
		'reset_date',
		'date_taken',
		'signature_date',
		'dnc_date',
		'date_transfer_weblead'
	];
}
