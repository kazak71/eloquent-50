<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class DropdownFinBy
 * 
 * @property int $id
 * @property string $fin_by
 * @property int $item_order
 * @property bool $disabled
 *
 * @package Models\Base
 */
class DropdownFinBy extends Eloquent
{
	protected $table = 'dropdown_fin_by';
	public $timestamps = false;

	protected $casts = [
		'item_order' => 'int',
		'disabled' => 'bool'
	];
}
