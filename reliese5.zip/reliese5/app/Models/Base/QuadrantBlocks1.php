<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class QuadrantBlocks1
 * 
 * @property int $id
 * @property int $id_quadrant
 * @property string $quadrant
 * @property string $empl
 * @property int $is_nh
 * @property int $id_lead
 * @property int $id_booker
 * @property \Carbon\Carbon $time_assigned
 * @property int $is_car_regy
 * @property string $block_type
 *
 * @package Models\Base
 */
class QuadrantBlocks1 extends Eloquent
{
	protected $table = 'quadrant_blocks_1';
	public $timestamps = false;

	protected $casts = [
		'id_quadrant' => 'int',
		'is_nh' => 'int',
		'id_lead' => 'int',
		'id_booker' => 'int',
		'is_car_regy' => 'int'
	];

	protected $dates = [
		'time_assigned'
	];
}
