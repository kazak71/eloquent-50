<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SalesrepWorkload
 * 
 * @property int $id
 * @property \Carbon\Carbon $work_date
 * @property int $id_salesrep
 * @property int $app1
 * @property int $app2
 * @property int $app3
 * @property int $app4
 * @property int $app5
 * @property int $app6
 *
 * @package Models\Base
 */
class SalesrepWorkload extends Eloquent
{
	protected $table = 'salesrep_workload';
	public $timestamps = false;

	protected $casts = [
		'id_salesrep' => 'int',
		'app1' => 'int',
		'app2' => 'int',
		'app3' => 'int',
		'app4' => 'int',
		'app5' => 'int',
		'app6' => 'int'
	];

	protected $dates = [
		'work_date'
	];
}
