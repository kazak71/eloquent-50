<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ReportP
 * 
 * @property int $id
 * @property int $id_user
 * @property int $id_lead
 * @property \Carbon\Carbon $date_survey
 * @property int $id_booker
 * @property \Carbon\Carbon $date_ps
 * @property string $script
 *
 * @package Models\Base
 */
class ReportP extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_user' => 'int',
		'id_lead' => 'int',
		'id_booker' => 'int'
	];

	protected $dates = [
		'date_survey',
		'date_ps'
	];
}
