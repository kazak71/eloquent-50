<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ReportLadsiHd
 * 
 * @property int $id
 * @property \Carbon\Carbon $report_for
 * @property int $material_total
 * @property float $return_percent
 * @property int $total_returned
 * @property float $qualified_percent
 * @property int $qualified_callable
 * @property float $phone_closing_percent
 * @property int $leads_monthly
 * @property int $leads_week
 * @property int $leads_day
 * @property int $leads_pfantino
 * @property float $lead_to_appt_percent
 * @property int $leads_percentages_to_install
 * @property int $appts_monthly
 * @property int $appts_week
 * @property int $appts_day
 * @property int $appts_pfantino
 * @property float $appt_to_demo_percent
 * @property int $appts_percentages_to_install
 * @property int $demos_monthly
 * @property int $demos_week
 * @property int $demos_day
 * @property int $demos_pfantino
 * @property float $demos_closing_percent
 * @property int $demos_percentages_to_install
 * @property int $sales_monthly
 * @property int $sales_week
 * @property int $sales_day
 * @property int $sales_pfantino
 * @property float $sales_install_percent
 * @property int $sales_percentages_to_install
 * @property int $installs_monthly
 * @property int $installs_week
 * @property int $installs_day
 * @property int $installs_pfantino
 * @property int $installs_percentages_to_install
 * @property float $total_cost
 * @property float $cps
 * @property float $pfantino
 * @property float $prize_give_away
 * @property float $premiums
 * @property float $printing
 * @property float $lead_cards
 * @property float $mailers
 * @property float $bd_sheets
 * @property float $signs
 * @property float $hand_outs
 * @property float $labor
 * @property float $commissions
 * @property float $bonuses
 * @property float $postage_out
 * @property float $postage_in
 * @property float $fees_for_show
 * @property float $supplies
 * @property float $bottles
 * @property float $drop_boxes
 * @property float $misc
 * @property \Carbon\Carbon $created_at
 *
 * @package Models\Base
 */
class ReportLadsiHd extends Eloquent
{
	protected $table = 'report_ladsi_hd';
	public $timestamps = false;

	protected $casts = [
		'material_total' => 'int',
		'return_percent' => 'float',
		'total_returned' => 'int',
		'qualified_percent' => 'float',
		'qualified_callable' => 'int',
		'phone_closing_percent' => 'float',
		'leads_monthly' => 'int',
		'leads_week' => 'int',
		'leads_day' => 'int',
		'leads_pfantino' => 'int',
		'lead_to_appt_percent' => 'float',
		'leads_percentages_to_install' => 'int',
		'appts_monthly' => 'int',
		'appts_week' => 'int',
		'appts_day' => 'int',
		'appts_pfantino' => 'int',
		'appt_to_demo_percent' => 'float',
		'appts_percentages_to_install' => 'int',
		'demos_monthly' => 'int',
		'demos_week' => 'int',
		'demos_day' => 'int',
		'demos_pfantino' => 'int',
		'demos_closing_percent' => 'float',
		'demos_percentages_to_install' => 'int',
		'sales_monthly' => 'int',
		'sales_week' => 'int',
		'sales_day' => 'int',
		'sales_pfantino' => 'int',
		'sales_install_percent' => 'float',
		'sales_percentages_to_install' => 'int',
		'installs_monthly' => 'int',
		'installs_week' => 'int',
		'installs_day' => 'int',
		'installs_pfantino' => 'int',
		'installs_percentages_to_install' => 'int',
		'total_cost' => 'float',
		'cps' => 'float',
		'pfantino' => 'float',
		'prize_give_away' => 'float',
		'premiums' => 'float',
		'printing' => 'float',
		'lead_cards' => 'float',
		'mailers' => 'float',
		'bd_sheets' => 'float',
		'signs' => 'float',
		'hand_outs' => 'float',
		'labor' => 'float',
		'commissions' => 'float',
		'bonuses' => 'float',
		'postage_out' => 'float',
		'postage_in' => 'float',
		'fees_for_show' => 'float',
		'supplies' => 'float',
		'bottles' => 'float',
		'drop_boxes' => 'float',
		'misc' => 'float'
	];

	protected $dates = [
		'report_for'
	];
}
