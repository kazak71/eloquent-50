<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class OfficeTrainer
 * 
 * @property int $id_trainer
 * @property string $fname
 * @property string $lname
 * @property \Carbon\Carbon $date_hired
 * @property int $people_trained
 * @property int $people_hired
 * @property bool $deleted
 *
 * @package Models\Base
 */
class OfficeTrainer extends Eloquent
{
	protected $primaryKey = 'id_trainer';
	public $timestamps = false;

	protected $casts = [
		'people_trained' => 'int',
		'people_hired' => 'int',
		'deleted' => 'bool'
	];

	protected $dates = [
		'date_hired'
	];
}
