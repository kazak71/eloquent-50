<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class MaterialSent
 * 
 * @property int $id
 * @property \Carbon\Carbon $date_sent
 * @property string $lead_type
 * @property string $lead_subtype
 * @property int $quantity
 *
 * @package Models\Base
 */
class MaterialSent extends Eloquent
{
	protected $table = 'material_sent';
	public $timestamps = false;

	protected $casts = [
		'quantity' => 'int'
	];

	protected $dates = [
		'date_sent'
	];
}
