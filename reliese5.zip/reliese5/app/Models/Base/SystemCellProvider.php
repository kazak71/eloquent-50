<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemCellProvider
 * 
 * @property int $id
 * @property string $descr
 * @property string $prefix
 * @property string $suffix
 * @property string $provider
 *
 * @package Models\Base
 */
class SystemCellProvider extends Eloquent
{
	public $timestamps = false;
}
