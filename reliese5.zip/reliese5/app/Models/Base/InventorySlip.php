<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class InventorySlip
 * 
 * @property int $id
 * @property int $order_number
 * @property \Carbon\Carbon $order_date
 * @property string $purchase_order
 * @property string $document_number
 * @property string $inventory_picker
 * @property string $comments
 * @property int $id_distributor_ship_to
 * @property int $id_distributor_bill_to
 * @property string $content
 * @property int $deleted
 * @property int $finalized
 * @property \Carbon\Carbon $date_finalized
 *
 * @package Models\Base
 */
class InventorySlip extends Eloquent
{
	protected $table = 'inventory_slip';
	public $timestamps = false;

	protected $casts = [
		'order_number' => 'int',
		'id_distributor_ship_to' => 'int',
		'id_distributor_bill_to' => 'int',
		'deleted' => 'int',
		'finalized' => 'int'
	];

	protected $dates = [
		'order_date',
		'date_finalized'
	];
}
