<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Appointment
 * 
 * @property int $id
 * @property int $id_lead
 * @property int $id_salesrep
 * @property int $id_installer
 * @property int $id_board
 * @property \Carbon\Carbon $app_date
 * @property \Carbon\Carbon $app_time
 * @property int $app_order
 * @property int $id_booker
 * @property \Carbon\Carbon $book_date
 * @property bool $not_active
 * @property \Carbon\Carbon $not_active_date
 * @property string $not_active_reason
 * @property string $return_reason
 * @property int $is_confirmed
 * @property int $id_confirmer
 * @property \Carbon\Carbon $confirm_date
 * @property \Carbon\Carbon $salesrep_in
 * @property \Carbon\Carbon $salesrep_out
 * @property string $notes_to_rep
 * @property \Carbon\Carbon $sms_time
 * @property int $ref_num
 * @property string $status
 * @property string $sld_status
 * @property string $fin_status
 * @property string $sold_type
 * @property string $fin_by
 * @property bool $is_sld
 * @property bool $is_edit
 * @property string $sold_system
 * @property int $sold_system_qty
 * @property string $app_notes
 * @property int $delivered
 * @property \Carbon\Carbon $reset_date
 * @property \Carbon\Carbon $transfer_to_service_time
 * @property int $transfer_to_service_user
 * @property int $id_user_app_mail
 * @property \Carbon\Carbon $app_mail_date
 * @property int $id_user_gc_hd_mail
 * @property \Carbon\Carbon $gc_hd_mail_date
 * @property string $gc_hd_mail_sent_to
 * @property int $gc_hd_id
 * @property int $id_user_gc_jcp_mail
 * @property \Carbon\Carbon $gc_jcp_mail_date
 * @property string $gc_jcp_mail_sent_to
 * @property int $gc_jcp_id
 *
 * @package Models\Base
 */
class Appointment extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_lead' => 'int',
		'id_salesrep' => 'int',
		'id_installer' => 'int',
		'id_board' => 'int',
		'app_order' => 'int',
		'id_booker' => 'int',
		'not_active' => 'bool',
		'is_confirmed' => 'int',
		'id_confirmer' => 'int',
		'ref_num' => 'int',
		'is_sld' => 'bool',
		'is_edit' => 'bool',
		'sold_system_qty' => 'int',
		'delivered' => 'int',
		'transfer_to_service_user' => 'int',
		'id_user_app_mail' => 'int',
		'id_user_gc_hd_mail' => 'int',
		'gc_hd_id' => 'int',
		'id_user_gc_jcp_mail' => 'int',
		'gc_jcp_id' => 'int'
	];

	protected $dates = [
		'app_date',
		'app_time',
		'book_date',
		'not_active_date',
		'confirm_date',
		'salesrep_in',
		'salesrep_out',
		'sms_time',
		'reset_date',
		'transfer_to_service_time',
		'app_mail_date',
		'gc_hd_mail_date',
		'gc_jcp_mail_date'
	];
}
