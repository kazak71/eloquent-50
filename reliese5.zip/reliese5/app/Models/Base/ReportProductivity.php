<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ReportProductivity
 * 
 * @property \Carbon\Carbon $work_date
 * @property int $booker_id
 * @property int $hours_worked
 * @property int $total_calls
 * @property int $total_sets
 * @property int $total_NI
 * @property int $total_leads_run
 *
 * @package Models\Base
 */
class ReportProductivity extends Eloquent
{
	protected $table = 'report_productivity';
	public $incrementing = false;
	public $timestamps = false;

	protected $casts = [
		'booker_id' => 'int',
		'hours_worked' => 'int',
		'total_calls' => 'int',
		'total_sets' => 'int',
		'total_NI' => 'int',
		'total_leads_run' => 'int'
	];

	protected $dates = [
		'work_date'
	];
}
