<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:30 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemUser
 * 
 * @property int $id
 * @property string $username
 * @property string $pass
 * @property string $type
 * @property string $subtype
 * @property string $fname
 * @property string $lname
 * @property \Carbon\Carbon $date_add
 * @property \Carbon\Carbon $date_delete
 * @property bool $deleted
 * @property float $hourly_rate
 * @property string $ssn
 * @property int $id_salesrep
 * @property int $inactive
 * @property string $home_phone
 * @property string $cell_phone
 * @property int $cell_provider
 * @property string $city
 * @property string $zip_postal
 * @property string $address1
 * @property string $associate_number
 * @property string $email
 * @property string $user_id
 * @property string $hd_source
 * @property \Carbon\Carbon $first_login_at
 * @property \Carbon\Carbon $showed_message_at
 * @property int $made_hd_surveys
 *
 * @package Models\Base
 */
class SystemUser extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'deleted' => 'bool',
		'hourly_rate' => 'float',
		'id_salesrep' => 'int',
		'inactive' => 'int',
		'cell_provider' => 'int',
		'made_hd_surveys' => 'int'
	];

	protected $dates = [
		'date_add',
		'date_delete',
		'first_login_at',
		'showed_message_at'
	];
}
