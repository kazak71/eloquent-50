<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemCompany
 * 
 * @property int $id
 * @property string $fname
 * @property string $lname
 * @property string $tel_cell
 * @property string $tel_home
 * @property string $fax
 * @property string $city
 * @property string $post_code
 * @property string $addr1
 * @property string $addr2
 * @property int $shipping_contact
 * @property string $company
 * @property string $email
 * @property int $deleted
 * @property string $url
 * @property string $db
 * @property string $type
 * @property string $api_username
 * @property string $api_password
 * @property int $po_enable
 * @property int $ship_to_enable
 * @property int $bill_to_enable
 *
 * @package Models\Base
 */
class SystemCompany extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'shipping_contact' => 'int',
		'deleted' => 'int',
		'po_enable' => 'int',
		'ship_to_enable' => 'int',
		'bill_to_enable' => 'int'
	];
}
