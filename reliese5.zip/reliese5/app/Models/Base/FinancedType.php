<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class FinancedType
 * 
 * @property int $financed_type_id
 * @property string $financed_type_name
 *
 * @package Models\Base
 */
class FinancedType extends Eloquent
{
	protected $table = 'financed_type';
	protected $primaryKey = 'financed_type_id';
	public $timestamps = false;
}
