<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SalesCopy
 * 
 * @property int $sale_id
 * @property int $lead_id
 * @property int $appointment_id
 * @property \Carbon\Carbon $sale_date
 * @property string $serials
 * @property float $price
 * @property int $sales_rep
 * @property string $sld_status
 * @property string $financed_type
 * @property string $hvac_size
 * @property string $misc
 * @property string $trade_in_type
 * @property string $financed_by
 * @property float $total_sales_price
 * @property float $down_payment
 * @property float $amount_financed
 * @property float $discount_amount
 * @property float $amount_received
 * @property \Carbon\Carbon $date_received
 * @property float $sales_tax_prcnt
 * @property float $sales_voucher
 * @property \Carbon\Carbon $date_pd
 * @property float $hvac
 * @property float $misc_attach
 * @property float $iaqs_commission
 * @property float $iaqs_bonus
 * @property float $iaqs_deductions
 * @property \Carbon\Carbon $iaqs_date_pd
 * @property float $distributor_pay
 * @property \Carbon\Carbon $distributor_date_pd
 * @property string $manager_name
 * @property float $manager_pay
 * @property \Carbon\Carbon $manager_date_pd
 * @property string $crew_leader_name
 * @property float $crew_leader_pay
 * @property \Carbon\Carbon $crew_leader_date_pd
 * @property float $trainer_pay
 * @property \Carbon\Carbon $trainer_date_pd
 * @property float $inv_sav_account
 * @property \Carbon\Carbon $inv_sav_account_date_pd
 * @property float $inventory_cost
 * @property \Carbon\Carbon $date_replaced_inventory
 * @property \Carbon\Carbon $date_modified
 * @property int $id_user_modified
 * @property string $img1
 * @property string $img2
 * @property string $img3
 * @property string $img4
 * @property string $img5
 * @property string $img6
 * @property string $img7
 * @property string $img8
 * @property string $img9
 * @property string $img10
 * @property int $deleted
 *
 * @package Models\Base
 */
class SalesCopy extends Eloquent
{
	protected $table = 'sales_copy';
	protected $primaryKey = 'sale_id';
	public $timestamps = false;

	protected $casts = [
		'lead_id' => 'int',
		'appointment_id' => 'int',
		'price' => 'float',
		'sales_rep' => 'int',
		'total_sales_price' => 'float',
		'down_payment' => 'float',
		'amount_financed' => 'float',
		'discount_amount' => 'float',
		'amount_received' => 'float',
		'sales_tax_prcnt' => 'float',
		'sales_voucher' => 'float',
		'hvac' => 'float',
		'misc_attach' => 'float',
		'iaqs_commission' => 'float',
		'iaqs_bonus' => 'float',
		'iaqs_deductions' => 'float',
		'distributor_pay' => 'float',
		'manager_pay' => 'float',
		'crew_leader_pay' => 'float',
		'trainer_pay' => 'float',
		'inv_sav_account' => 'float',
		'inventory_cost' => 'float',
		'id_user_modified' => 'int',
		'deleted' => 'int'
	];

	protected $dates = [
		'sale_date',
		'date_received',
		'date_pd',
		'iaqs_date_pd',
		'distributor_date_pd',
		'manager_date_pd',
		'crew_leader_date_pd',
		'trainer_date_pd',
		'inv_sav_account_date_pd',
		'date_replaced_inventory',
		'date_modified'
	];
}
