<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:30 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class TransferredSet
 * 
 * @property int $id
 * @property int $id_set
 * @property \Carbon\Carbon $date_transfer
 * @property int $id_user
 *
 * @package Models\Base
 */
class TransferredSet extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_set' => 'int',
		'id_user' => 'int'
	];

	protected $dates = [
		'date_transfer'
	];
}
