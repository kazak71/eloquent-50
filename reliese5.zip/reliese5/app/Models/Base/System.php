<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:30 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class System
 * 
 * @property int $id
 * @property string $fname
 * @property string $lname
 * @property string $tel_cell
 * @property string $tel_home
 * @property string $fax
 * @property string $city
 * @property string $post_code
 * @property string $addr1
 * @property string $addr2
 * @property int $shipping_contact
 * @property string $company
 * @property string $email
 * @property string $url
 * @property string $type
 * @property string $api_username
 * @property string $api_password
 *
 * @package Models\Base
 */
class System extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'shipping_contact' => 'int'
	];
}
