<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ManAd
 * 
 * @property int $id_ad
 * @property int $id_manager
 * @property string $ad_place
 * @property float $ad_price
 * @property \Carbon\Carbon $ad_start_date
 * @property \Carbon\Carbon $ad_end_date
 * @property string $ad_text
 * @property bool $ad_deleted
 * @property string $ad_title
 * @property int $ad_calls
 * @property int $ad_hired
 *
 * @package Models\Base
 */
class ManAd extends Eloquent
{
	protected $table = 'man_ad';
	protected $primaryKey = 'id_ad';
	public $timestamps = false;

	protected $casts = [
		'id_manager' => 'int',
		'ad_price' => 'float',
		'ad_deleted' => 'bool',
		'ad_calls' => 'int',
		'ad_hired' => 'int'
	];

	protected $dates = [
		'ad_start_date',
		'ad_end_date'
	];
}
