<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemSalesrep
 * 
 * @property int $id
 * @property string $fname
 * @property string $lname
 * @property int $id_provider
 * @property string $tel_cell
 * @property string $tel_home
 * @property string $fax
 * @property string $city
 * @property string $post_code
 * @property string $addr1
 * @property string $addr2
 * @property string $trainer
 * @property string $last_digits_ssn
 * @property int $deleted
 * @property string $email
 * @property string $associate_number
 * @property int $inactive
 * @property \Carbon\Carbon $date_created
 *
 * @package Models\Base
 */
class SystemSalesrep extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_provider' => 'int',
		'deleted' => 'int',
		'inactive' => 'int'
	];

	protected $dates = [
		'date_created'
	];
}
