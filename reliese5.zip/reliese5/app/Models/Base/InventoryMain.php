<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class InventoryMain
 * 
 * @property int $id
 * @property string $serial_number
 * @property int $id_manager_inserted
 * @property int $id_model
 * @property int $quantity
 * @property int $deleted
 * @property \Carbon\Carbon $date_inserted
 * @property \Carbon\Carbon $date_modified
 *
 * @package Models\Base
 */
class InventoryMain extends Eloquent
{
	protected $table = 'inventory_main';
	public $timestamps = false;

	protected $casts = [
		'id_manager_inserted' => 'int',
		'id_model' => 'int',
		'quantity' => 'int',
		'deleted' => 'int'
	];

	protected $dates = [
		'date_inserted',
		'date_modified'
	];
}
