<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class AppBoard
 * 
 * @property int $id
 * @property string $name
 * @property bool $deleted
 *
 * @package Models\Base
 */
class AppBoard extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'deleted' => 'bool'
	];
}
