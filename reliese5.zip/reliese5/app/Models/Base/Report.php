<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Report
 * 
 * @property int $id
 * @property int $id_agent
 * @property \Carbon\Carbon $date_contact
 * @property \Carbon\Carbon $date_call
 * @property string $status
 * @property int $id_lead
 * @property int $na_level
 * @property string $script
 *
 * @package Models\Base
 */
class Report extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_agent' => 'int',
		'id_lead' => 'int',
		'na_level' => 'int'
	];

	protected $dates = [
		'date_contact',
		'date_call'
	];
}
