<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ReportDailySale
 * 
 * @property \Carbon\Carbon $date
 * @property int $Budget_Man_Hours
 * @property int $Trng_Wknd
 * @property int $Recrts
 * @property int $Demos
 * @property int $Grs_Trans
 * @property int $Pend
 * @property int $Net_Trans
 * @property int $Training_F3000
 * @property int $Training_SFS
 *
 * @package Models\Base
 */
class ReportDailySale extends Eloquent
{
	protected $primaryKey = 'date';
	public $incrementing = false;
	public $timestamps = false;

	protected $casts = [
		'Budget_Man_Hours' => 'int',
		'Trng_Wknd' => 'int',
		'Recrts' => 'int',
		'Demos' => 'int',
		'Grs_Trans' => 'int',
		'Pend' => 'int',
		'Net_Trans' => 'int',
		'Training_F3000' => 'int',
		'Training_SFS' => 'int'
	];

	protected $dates = [
		'date'
	];
}
