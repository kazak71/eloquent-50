<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SurveyCost
 * 
 * @property \Carbon\Carbon $week_start
 * @property float $cost
 * @property \Carbon\Carbon $last_updated
 *
 * @package Models\Base
 */
class SurveyCost extends Eloquent
{
	protected $table = 'survey_cost';
	protected $primaryKey = 'week_start';
	public $incrementing = false;
	public $timestamps = false;

	protected $casts = [
		'cost' => 'float'
	];

	protected $dates = [
		'week_start',
		'last_updated'
	];
}
