<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Clock
 * 
 * @property int $clock_id
 * @property \Carbon\Carbon $clock_time
 * @property int $user_id
 * @property string $direction
 * @property string $photo
 *
 * @package Models\Base
 */
class Clock extends Eloquent
{
	protected $primaryKey = 'clock_id';
	public $timestamps = false;

	protected $casts = [
		'user_id' => 'int'
	];

	protected $dates = [
		'clock_time'
	];
}
