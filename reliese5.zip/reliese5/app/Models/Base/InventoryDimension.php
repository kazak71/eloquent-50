<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class InventoryDimension
 * 
 * @property int $id_dimension
 * @property string $dimension
 *
 * @package Models\Base
 */
class InventoryDimension extends Eloquent
{
	protected $primaryKey = 'id_dimension';
	public $timestamps = false;
}
