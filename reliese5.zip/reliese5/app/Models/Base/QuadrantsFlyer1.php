<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class QuadrantsFlyer1
 * 
 * @property int $id
 * @property string $name
 * @property \Carbon\Carbon $setting_date
 * @property int $setter_priority
 * @property bool $hold
 *
 * @package Models\Base
 */
class QuadrantsFlyer1 extends Eloquent
{
	protected $table = 'quadrants_flyer_1';
	public $timestamps = false;

	protected $casts = [
		'setter_priority' => 'int',
		'hold' => 'bool'
	];

	protected $dates = [
		'setting_date'
	];
}
