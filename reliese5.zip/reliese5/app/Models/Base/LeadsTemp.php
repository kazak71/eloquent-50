<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class LeadsTemp
 * 
 * @property string $name
 * @property string $address
 * @property string $city
 * @property string $state
 * @property string $zip
 * @property string $phone
 * @property string $lead_type
 * @property string $lead_subtype
 *
 * @package Models\Base
 */
class LeadsTemp extends Eloquent
{
	protected $table = 'leads_temp';
	protected $primaryKey = 'phone';
	public $incrementing = false;
	public $timestamps = false;
}
