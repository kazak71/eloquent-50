<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class LeadsGiftCard
 * 
 * @property int $id
 * @property string $name
 * @property string $phone
 * @property string $best_contact_date
 * @property string $best_contact_time
 * @property string $address
 * @property string $city
 * @property string $state
 * @property string $zip
 * @property string $email
 * @property string $email_2
 * @property string $agree_terms
 * @property string $home_owner
 * @property string $eat_out
 * @property string $eatprefer
 * @property string $restaurant_frequented
 * @property string $give_opinion
 * @property string $bottle_water
 * @property string $bottle_water_type
 * @property string $home_devices
 * @property string $home_type
 * @property string $household_head
 * @property string $amazon_shopped
 * @property string $amazon_average_purchase
 * @property string $websites_shop
 * @property string $age
 * @property string $occupants
 * @property string $work_in
 * @property string $work_in_m
 * @property \Carbon\Carbon $date_survey
 * @property string $card_type
 * @property \Carbon\Carbon $recall_date
 * @property int $id_booker_recall
 * @property string $book_status
 * @property int $id_booker
 * @property \Carbon\Carbon $booker_lastcall
 * @property int $nh_level_book
 * @property int $id_lead
 * @property \Carbon\Carbon $date_transfer
 * @property string $occupation
 *
 * @package Models\Base
 */
class LeadsGiftCard extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_booker_recall' => 'int',
		'id_booker' => 'int',
		'nh_level_book' => 'int',
		'id_lead' => 'int'
	];

	protected $dates = [
		'date_survey',
		'recall_date',
		'booker_lastcall',
		'date_transfer'
	];
}
