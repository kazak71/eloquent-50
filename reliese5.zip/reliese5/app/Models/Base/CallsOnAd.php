<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class CallsOnAd
 * 
 * @property int $id_call
 * @property int $id_ad
 * @property string $fname
 * @property string $lname
 * @property string $tel_cell
 * @property string $tel_home
 * @property string $e_mail
 * @property string $address1
 * @property string $address2
 * @property string $city
 * @property string $state
 * @property string $zip
 * @property \Carbon\Carbon $date_call
 * @property string $trainer_arranged
 * @property bool $approved
 * @property \Carbon\Carbon $interview_time
 * @property \Carbon\Carbon $interview_date
 * @property bool $deleted
 * @property bool $hired
 * @property string $status
 *
 * @package Models\Base
 */
class CallsOnAd extends Eloquent
{
	protected $table = 'calls_on_ad';
	protected $primaryKey = 'id_call';
	public $timestamps = false;

	protected $casts = [
		'id_ad' => 'int',
		'approved' => 'bool',
		'deleted' => 'bool',
		'hired' => 'bool'
	];

	protected $dates = [
		'date_call',
		'interview_time',
		'interview_date'
	];
}
