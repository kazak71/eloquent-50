<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:30 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemSource
 * 
 * @property int $id
 * @property string $source
 * @property string $lead_type
 *
 * @package Models\Base
 */
class SystemSource extends Eloquent
{
	protected $table = 'system_source';
	public $timestamps = false;
}
