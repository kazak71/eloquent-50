<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemLeadSubtype
 * 
 * @property int $id
 * @property string $subtype
 * @property string $lead_type
 * @property int $deleted
 *
 * @package Models\Base
 */
class SystemLeadSubtype extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'deleted' => 'int'
	];
}
