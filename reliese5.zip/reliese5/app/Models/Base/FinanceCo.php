<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class FinanceCo
 * 
 * @property int $finance_co_id
 * @property string $finance_co_name
 *
 * @package Models\Base
 */
class FinanceCo extends Eloquent
{
	protected $table = 'finance_co';
	protected $primaryKey = 'finance_co_id';
	public $timestamps = false;
}
