<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 23 Jun 2018 09:34:29 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class GiftCardsHd
 * 
 * @property int $id
 * @property string $row_id
 * @property string $brand
 * @property string $egift_number
 * @property string $url
 * @property string $challenge_code
 * @property string $denomination
 * @property string $recipient_name
 * @property string $message
 * @property string $token
 * @property int $id_lead
 * @property int $id_user_add
 * @property int $id_app
 * @property string $app_status
 * @property bool $sent
 * @property \Carbon\Carbon $created_at
 *
 * @package Models\Base
 */
class GiftCardsHd extends Eloquent
{
	protected $table = 'gift_cards_hd';
	public $timestamps = false;

	protected $casts = [
		'id_lead' => 'int',
		'id_user_add' => 'int',
		'id_app' => 'int',
		'sent' => 'bool'
	];
}
