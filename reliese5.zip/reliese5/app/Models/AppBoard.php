<?php

namespace Models;

class AppBoard extends \Models\Base\AppBoard
{
	protected $fillable = [
		'name',
		'deleted'
	];
}
