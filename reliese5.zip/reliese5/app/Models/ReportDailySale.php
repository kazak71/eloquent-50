<?php

namespace Models;

class ReportDailySale extends \Models\Base\ReportDailySale
{
	protected $fillable = [
		'Budget_Man_Hours',
		'Trng_Wknd',
		'Recrts',
		'Demos',
		'Grs_Trans',
		'Pend',
		'Net_Trans',
		'Training_F3000',
		'Training_SFS'
	];
}
