<?php

namespace Models;

class OfficeTrainer extends \Models\Base\OfficeTrainer
{
	protected $fillable = [
		'fname',
		'lname',
		'date_hired',
		'people_trained',
		'people_hired',
		'deleted'
	];
}
