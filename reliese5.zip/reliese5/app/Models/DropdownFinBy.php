<?php

namespace Models;

class DropdownFinBy extends \Models\Base\DropdownFinBy
{
	protected $fillable = [
		'fin_by',
		'item_order',
		'disabled'
	];
}
