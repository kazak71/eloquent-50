<?php

namespace Models;

class SystemCompany extends \Models\Base\SystemCompany
{
	protected $hidden = [
		'api_password'
	];

	protected $fillable = [
		'fname',
		'lname',
		'tel_cell',
		'tel_home',
		'fax',
		'city',
		'post_code',
		'addr1',
		'addr2',
		'shipping_contact',
		'company',
		'email',
		'deleted',
		'url',
		'db',
		'type',
		'api_username',
		'api_password',
		'po_enable',
		'ship_to_enable',
		'bill_to_enable'
	];
}
