<?php

namespace Models;

class WarrantyLog extends \Models\Base\WarrantyLog
{
	protected $fillable = [
		'first_name',
		'last_name',
		'street_address',
		'address_line_2',
		'city',
		'state',
		'zip',
		'home_phone',
		'email',
		'model',
		'serial_number',
		'date_purchased',
		'associate_name',
		'associate_number',
		'phone_pro_name',
		'id_app',
		'id_lead'
	];
}
