<?php

namespace Models;

class SalesrepWorkload extends \Models\Base\SalesrepWorkload
{
	protected $fillable = [
		'work_date',
		'id_salesrep',
		'app1',
		'app2',
		'app3',
		'app4',
		'app5',
		'app6'
	];
}
