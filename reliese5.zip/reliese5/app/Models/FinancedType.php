<?php

namespace Models;

class FinancedType extends \Models\Base\FinancedType
{
	protected $fillable = [
		'financed_type_name'
	];
}
