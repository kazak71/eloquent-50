<?php

namespace Models;

class Report extends \Models\Base\Report
{
	protected $fillable = [
		'id_agent',
		'date_call',
		'status',
		'id_lead',
		'id_set',
		'block',
		'na_level',
		'script',
		'lead_type',
		'lead_subtype'
	];
}
