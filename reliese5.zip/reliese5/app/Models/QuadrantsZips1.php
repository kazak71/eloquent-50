<?php

namespace Models;

class QuadrantsZips1 extends \Models\Base\QuadrantsZips1
{
	protected $fillable = [
		'id_quadrant',
		'zip'
	];
}
