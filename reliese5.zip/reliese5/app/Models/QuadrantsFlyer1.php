<?php

namespace Models;

class QuadrantsFlyer1 extends \Models\Base\QuadrantsFlyer1
{
	protected $fillable = [
		'name',
		'setting_date',
		'setter_priority',
		'hold'
	];
}
