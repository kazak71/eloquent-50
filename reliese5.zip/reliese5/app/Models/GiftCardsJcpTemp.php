<?php

namespace Models;

class GiftCardsJcpTemp extends \Models\Base\GiftCardsJcpTemp
{
	protected $hidden = [
		'token'
	];

	protected $fillable = [
		'row_id',
		'brand',
		'egift_number',
		'url',
		'challenge_code',
		'denomination',
		'recipient_name',
		'message',
		'token',
		'id_lead',
		'id_user_add',
		'id_app',
		'sent'
	];
}
