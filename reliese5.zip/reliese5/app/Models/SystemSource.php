<?php

namespace Models;

class SystemSource extends \Models\Base\SystemSource
{
	protected $fillable = [
		'source',
		'lead_type'
	];
}
