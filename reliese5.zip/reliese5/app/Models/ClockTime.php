<?php

namespace Models;

class ClockTime extends \Models\Base\ClockTime
{
	protected $fillable = [
		'clock_time',
		'clock_date',
		'cl_time',
		'user_names',
		'direction',
		'user_id',
		'time_total',
		'photo'
	];
}
