<?php

namespace Models;

class Note extends \Models\Base\Note
{
	protected $fillable = [
		'id_lead',
		'id_agent',
		'note'
	];
}
