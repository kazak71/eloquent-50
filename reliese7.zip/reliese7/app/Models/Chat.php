<?php

namespace Models;

class Chat extends \Models\Base\Chat
{
	protected $fillable = [
		'from',
		'to',
		'message',
		'sent',
		'recd'
	];
}
