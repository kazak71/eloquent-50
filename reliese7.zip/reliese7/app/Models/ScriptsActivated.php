<?php

namespace Models;

class ScriptsActivated extends \Models\Base\ScriptsActivated
{
	protected $fillable = [
		'script',
		'last_access'
	];
}
