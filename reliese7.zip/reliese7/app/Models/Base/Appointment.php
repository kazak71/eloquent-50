<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Appointment
 * 
 * @property int $id
 * @property int $id_lead
 * @property int $id_salesrep
 * @property int $id_job
 * @property \Carbon\Carbon $app_date
 * @property \Carbon\Carbon $app_time
 * @property string $duration
 * @property int $id_booker
 * @property \Carbon\Carbon $book_date
 * @property string $app_notes
 * @property string $tech_notes
 * @property string $status
 * @property string $claim
 * @property float $to_collect
 * @property string $collected
 * @property string $check_number
 * @property string $bill_to
 * @property string $to_be_billed
 * @property string $autho_number
 * @property string $reason_for_nc
 * @property \Carbon\Carbon $sms_time
 * @property int $id_app_sender
 * @property string $additional_tech
 *
 * @package Models\Base
 */
class Appointment extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_lead' => 'int',
		'id_salesrep' => 'int',
		'id_job' => 'int',
		'id_booker' => 'int',
		'to_collect' => 'float',
		'id_app_sender' => 'int'
	];

	protected $dates = [
		'app_date',
		'app_time',
		'book_date',
		'sms_time'
	];
}
