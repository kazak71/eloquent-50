<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Note
 * 
 * @property int $id
 * @property int $id_lead
 * @property \Carbon\Carbon $created_at
 * @property int $id_agent
 * @property string $note
 *
 * @package Models\Base
 */
class Note extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_lead' => 'int',
		'id_agent' => 'int'
	];
}
