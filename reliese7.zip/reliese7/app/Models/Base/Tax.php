<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Tax
 * 
 * @property int $id
 * @property string $description
 * @property float $tax_percent
 * @property int $deleted
 * @property \Carbon\Carbon $date_delete
 *
 * @package Models\Base
 */
class Tax extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'tax_percent' => 'float',
		'deleted' => 'int'
	];

	protected $dates = [
		'date_delete'
	];
}
