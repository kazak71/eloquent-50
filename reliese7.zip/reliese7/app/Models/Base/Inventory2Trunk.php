<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Inventory2Trunk
 * 
 * @property int $id
 * @property int $id_inventory_main
 * @property int $id_user
 * @property int $quantity
 * @property \Carbon\Carbon $date_modified
 *
 * @package Models\Base
 */
class Inventory2Trunk extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_inventory_main' => 'int',
		'id_user' => 'int',
		'quantity' => 'int'
	];

	protected $dates = [
		'date_modified'
	];
}
