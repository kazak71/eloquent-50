<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Paypal
 * 
 * @property int $id
 * @property int $user_id
 * @property string $ip
 * @property string $paypal_array
 * @property string $descr
 * @property \Carbon\Carbon $pay_month
 * @property float $pay_sum
 * @property \Carbon\Carbon $updated_time
 * @property int $to_arc
 *
 * @package Models\Base
 */
class Paypal extends Eloquent
{
	protected $table = 'paypal';
	public $timestamps = false;

	protected $casts = [
		'user_id' => 'int',
		'pay_sum' => 'float',
		'to_arc' => 'int'
	];

	protected $dates = [
		'pay_month',
		'updated_time'
	];
}
