<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Inventory2Model
 * 
 * @property int $id
 * @property string $partno
 * @property string $description
 * @property string $material
 * @property string $finish_color
 * @property int $type
 * @property int $deleted
 * @property string $belong_to
 * @property int $last_modified
 * @property int $tbd_view
 * @property int $gift
 * @property float $price
 *
 * @package Models\Base
 */
class Inventory2Model extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'type' => 'int',
		'deleted' => 'int',
		'last_modified' => 'int',
		'tbd_view' => 'int',
		'gift' => 'int',
		'price' => 'float'
	];
}
