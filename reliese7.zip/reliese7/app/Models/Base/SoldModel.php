<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SoldModel
 * 
 * @property int $id
 * @property string $partno
 * @property string $description
 * @property bool $deleted
 *
 * @package Models\Base
 */
class SoldModel extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'deleted' => 'bool'
	];
}
