<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Waiver
 * 
 * @property int $id
 * @property int $id_job
 * @property int $id_agent
 * @property string $name
 * @property \Carbon\Carbon $test_date
 * @property \Carbon\Carbon $customer_date
 * @property string $water_pressure
 * @property string $prv_recommended
 * @property \Carbon\Carbon $witness_date
 * @property string $customer_signature
 * @property string $witness_signature
 * @property \Carbon\Carbon $created_at
 *
 * @package Models\Base
 */
class Waiver extends Eloquent
{
	protected $table = 'waiver';
	public $timestamps = false;

	protected $casts = [
		'id_job' => 'int',
		'id_agent' => 'int'
	];

	protected $dates = [
		'test_date',
		'customer_date',
		'witness_date'
	];
}
