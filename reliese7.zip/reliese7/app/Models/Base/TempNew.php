<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class TempNew
 * 
 * @property int $lead_id
 * @property string $type
 * @property \Carbon\Carbon $date
 * @property string $item
 * @property int $qty
 * @property string $price
 * @property float $amount
 *
 * @package Models\Base
 */
class TempNew extends Eloquent
{
	protected $table = 'temp_new';
	public $incrementing = false;
	public $timestamps = false;

	protected $casts = [
		'lead_id' => 'int',
		'qty' => 'int',
		'amount' => 'float'
	];

	protected $dates = [
		'date'
	];
}
