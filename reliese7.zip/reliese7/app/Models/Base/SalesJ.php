<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SalesJ
 * 
 * @property int $sale_id
 * @property int $lead_id
 * @property int $appointment_id
 * @property \Carbon\Carbon $sale_date
 * @property string $serials
 * @property float $price
 * @property int $sales_rep
 * @property string $sld_status
 * @property \Carbon\Carbon $date_modified
 * @property int $id_user_modified
 * @property string $finance_co
 * @property float $amt_fin
 * @property float $fin_pd
 * @property string $cc_comp
 * @property float $cc_pd
 * @property float $chk_pd
 * @property float $cash_pd
 * @property float $gaamt
 * @property float $comm
 * @property float $cog
 * @property float $overrd
 * @property float $adcst
 * @property bool $taxable
 * @property float $tax_rate
 * @property \Carbon\Carbon $install_date
 * @property string $lead_source
 * @property string $notes
 * @property string $product_details
 * @property string $package
 * @property string $payment_details
 * @property \Carbon\Carbon $paid_on
 * @property \Carbon\Carbon $date_invoiced
 * @property float $amt_invoiced
 * @property \Carbon\Carbon $invoice_pd
 *
 * @package Models\Base
 */
class SalesJ extends Eloquent
{
	protected $table = 'sales_j';
	protected $primaryKey = 'sale_id';
	public $timestamps = false;

	protected $casts = [
		'lead_id' => 'int',
		'appointment_id' => 'int',
		'price' => 'float',
		'sales_rep' => 'int',
		'id_user_modified' => 'int',
		'amt_fin' => 'float',
		'fin_pd' => 'float',
		'cc_pd' => 'float',
		'chk_pd' => 'float',
		'cash_pd' => 'float',
		'gaamt' => 'float',
		'comm' => 'float',
		'cog' => 'float',
		'overrd' => 'float',
		'adcst' => 'float',
		'taxable' => 'bool',
		'tax_rate' => 'float',
		'amt_invoiced' => 'float'
	];

	protected $dates = [
		'sale_date',
		'date_modified',
		'install_date',
		'paid_on',
		'date_invoiced',
		'invoice_pd'
	];
}
