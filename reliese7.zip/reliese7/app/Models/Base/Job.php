<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Job
 * 
 * @property int $id
 * @property int $id_lead
 * @property string $number
 * @property string $type
 * @property int $id_salesrep
 * @property int $id_booker
 * @property \Carbon\Carbon $created
 * @property string $notes
 * @property bool $deleted
 * @property int $id_app_sender
 * @property \Carbon\Carbon $completed
 *
 * @package Models\Base
 */
class Job extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_lead' => 'int',
		'id_salesrep' => 'int',
		'id_booker' => 'int',
		'deleted' => 'bool',
		'id_app_sender' => 'int'
	];

	protected $dates = [
		'created',
		'completed'
	];
}
