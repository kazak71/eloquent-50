<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Clock
 * 
 * @property int $clock_id
 * @property \Carbon\Carbon $clock_time
 * @property int $user_id
 * @property string $username
 * @property int $direction
 * @property int $type_id
 * @property string $notes
 *
 * @package Models\Base
 */
class Clock extends Eloquent
{
	protected $primaryKey = 'clock_id';
	public $timestamps = false;

	protected $casts = [
		'user_id' => 'int',
		'direction' => 'int',
		'type_id' => 'int'
	];

	protected $dates = [
		'clock_time'
	];
}
