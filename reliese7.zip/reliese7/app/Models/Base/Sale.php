<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Sale
 * 
 * @property int $id
 * @property int $id_lead
 * @property string $product
 * @property \Carbon\Carbon $sales_date
 * @property string $sales_notes
 * @property int $id_app_sender
 *
 * @package Models\Base
 */
class Sale extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_lead' => 'int',
		'id_app_sender' => 'int'
	];

	protected $dates = [
		'sales_date'
	];
}
