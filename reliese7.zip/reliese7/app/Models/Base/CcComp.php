<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class CcComp
 * 
 * @property int $cc_comp_id
 * @property string $cc_comp_name
 *
 * @package Models\Base
 */
class CcComp extends Eloquent
{
	protected $table = 'cc_comp';
	protected $primaryKey = 'cc_comp_id';
	public $timestamps = false;
}
