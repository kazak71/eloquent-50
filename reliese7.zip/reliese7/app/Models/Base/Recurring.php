<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Recurring
 * 
 * @property int $id
 * @property int $lead_id
 * @property \Carbon\Carbon $recurring_date
 *
 * @package Models\Base
 */
class Recurring extends Eloquent
{
	protected $table = 'recurring';
	public $timestamps = false;

	protected $casts = [
		'lead_id' => 'int'
	];

	protected $dates = [
		'recurring_date'
	];
}
