<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SoldInventory
 * 
 * @property int $id
 * @property \Carbon\Carbon $date_sold
 * @property int $lead_id
 * @property int $app_id
 * @property int $id_model
 * @property string $description
 * @property string $serial_number
 * @property int $quantity
 * @property float $amount
 * @property string $memo
 * @property \Carbon\Carbon $date_modified
 *
 * @package Models\Base
 */
class SoldInventory extends Eloquent
{
	protected $table = 'sold_inventory';
	public $timestamps = false;

	protected $casts = [
		'lead_id' => 'int',
		'app_id' => 'int',
		'id_model' => 'int',
		'quantity' => 'int',
		'amount' => 'float'
	];

	protected $dates = [
		'date_sold',
		'date_modified'
	];
}
