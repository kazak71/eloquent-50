<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ServiceOrder
 * 
 * @property int $id
 * @property int $id_job
 * @property int $id_salesrep
 * @property int $id_agent
 * @property string $name
 * @property string $address
 * @property string $city
 * @property string $phone
 * @property string $phone_2
 * @property string $cell
 * @property \Carbon\Carbon $order_taken_date
 * @property \Carbon\Carbon $order_taken_time
 * @property \Carbon\Carbon $date_serviced
 * @property string $arrival
 * @property string $departure
 * @property string $others
 * @property string $parts
 * @property string $signature
 * @property \Carbon\Carbon $created_at
 *
 * @package Models\Base
 */
class ServiceOrder extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_job' => 'int',
		'id_salesrep' => 'int',
		'id_agent' => 'int'
	];

	protected $dates = [
		'order_taken_date',
		'order_taken_time',
		'date_serviced'
	];
}
