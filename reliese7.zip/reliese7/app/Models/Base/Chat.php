<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Chat
 * 
 * @property int $id
 * @property string $from
 * @property string $to
 * @property string $message
 * @property \Carbon\Carbon $sent
 * @property int $recd
 *
 * @package Models\Base
 */
class Chat extends Eloquent
{
	protected $table = 'chat';
	public $timestamps = false;

	protected $casts = [
		'recd' => 'int'
	];

	protected $dates = [
		'sent'
	];
}
