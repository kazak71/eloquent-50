<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ScriptsActivated
 * 
 * @property int $id
 * @property string $script
 * @property \Carbon\Carbon $last_access
 *
 * @package Models\Base
 */
class ScriptsActivated extends Eloquent
{
	protected $table = 'scripts_activated';
	public $timestamps = false;

	protected $dates = [
		'last_access'
	];
}
