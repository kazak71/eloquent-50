<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ClockTime
 * 
 * @property int $clock_id
 * @property \Carbon\Carbon $clock_time
 * @property \Carbon\Carbon $clock_date
 * @property \Carbon\Carbon $cl_time
 * @property int $cl_id
 * @property string $username
 * @property int $direction
 * @property int $type_id
 * @property int $user_id
 * @property string $notes
 * @property \Carbon\Carbon $time_total
 *
 * @package Models\Base
 */
class ClockTime extends Eloquent
{
	protected $primaryKey = 'clock_id';
	public $timestamps = false;

	protected $casts = [
		'cl_id' => 'int',
		'direction' => 'int',
		'type_id' => 'int',
		'user_id' => 'int'
	];

	protected $dates = [
		'clock_time',
		'clock_date',
		'cl_time',
		'time_total'
	];
}
