<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class NotesTemp
 * 
 * @property int $id
 * @property string $phone
 * @property string $note
 *
 * @package Models\Base
 */
class NotesTemp extends Eloquent
{
	protected $table = 'notes_temp';
	public $timestamps = false;
}
