<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 16:16:02 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Temp
 * 
 * @property int $num
 * @property string $type
 * @property \Carbon\Carbon $date
 * @property string $source_name
 * @property string $address
 * @property string $street1
 * @property string $city
 * @property string $province
 * @property string $postal_code
 * @property string $name
 * @property string $item
 * @property int $qty
 * @property string $price
 * @property float $amount
 *
 * @package Models\Base
 */
class Temp extends Eloquent
{
	protected $table = 'temp';
	public $incrementing = false;
	public $timestamps = false;

	protected $casts = [
		'num' => 'int',
		'qty' => 'int',
		'amount' => 'float'
	];

	protected $dates = [
		'date'
	];
}
