<?php

namespace Models;

class SystemOffice extends \Models\Base\SystemOffice
{
	protected $fillable = [
		'office_name',
		'office_db',
		'to_arc'
	];
}
