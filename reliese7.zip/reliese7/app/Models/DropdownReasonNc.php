<?php

namespace Models;

class DropdownReasonNc extends \Models\Base\DropdownReasonNc
{
	protected $fillable = [
		'reason_for_nc',
		'disabled',
		'position'
	];
}
