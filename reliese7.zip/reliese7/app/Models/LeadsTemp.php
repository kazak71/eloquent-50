<?php

namespace Models;

class LeadsTemp extends \Models\Base\LeadsTemp
{
	protected $fillable = [
		'n',
		'Date',
		'Name',
		'Street',
		'City',
		'Province',
		'Postal_code',
		'Phone',
		'Phone2',
		'Memo',
		'Item',
		'Qty',
		'Amount',
		'product',
		'sales_detail',
		'email'
	];
}
