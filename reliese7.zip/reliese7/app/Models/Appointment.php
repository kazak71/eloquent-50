<?php

namespace Models;

class Appointment extends \Models\Base\Appointment
{
	protected $fillable = [
		'id_lead',
		'id_salesrep',
		'id_job',
		'app_date',
		'app_time',
		'duration',
		'id_booker',
		'book_date',
		'app_notes',
		'tech_notes',
		'status',
		'claim',
		'to_collect',
		'collected',
		'check_number',
		'bill_to',
		'to_be_billed',
		'autho_number',
		'reason_for_nc',
		'sms_time',
		'id_app_sender',
		'additional_tech'
	];
}
