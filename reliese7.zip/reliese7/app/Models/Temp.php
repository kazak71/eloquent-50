<?php

namespace Models;

class Temp extends \Models\Base\Temp
{
	protected $fillable = [
		'num',
		'type',
		'date',
		'source_name',
		'address',
		'street1',
		'city',
		'province',
		'postal_code',
		'name',
		'item',
		'qty',
		'price',
		'amount'
	];
}
