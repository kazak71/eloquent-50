<?php

namespace Models;

class DropdownBillTo extends \Models\Base\DropdownBillTo
{
	protected $fillable = [
		'bill_to',
		'disabled'
	];
}
