<?php

namespace Models;

class SystemUser extends \Models\Base\SystemUser
{
	protected $fillable = [
		'username',
		'pass',
		'type',
		'subtype',
		'fname',
		'lname',
		'id_provider',
		'tel_cell',
		'tel_home',
		'fax',
		'city',
		'post_code',
		'addr1',
		'addr2',
		'deleted',
		'date_delete',
		'date_add',
		'inactive',
		'email'
	];
}
