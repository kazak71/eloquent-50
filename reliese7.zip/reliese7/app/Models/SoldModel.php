<?php

namespace Models;

class SoldModel extends \Models\Base\SoldModel
{
	protected $fillable = [
		'partno',
		'description',
		'deleted'
	];
}
