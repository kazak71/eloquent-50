<?php

namespace Models;

class CcComp extends \Models\Base\CcComp
{
	protected $fillable = [
		'cc_comp_name'
	];
}
