<?php

namespace Models;

class Geolocation extends \Models\Base\Geolocation
{
	protected $fillable = [
		'lat',
		'lon',
		'loctime'
	];
}
